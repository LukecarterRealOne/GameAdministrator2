package com.gameadmin.mod.client;

import com.gameadmin.mod.Ability;
import com.gameadmin.mod.CastRequestPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/** The Game Administrator console: a 3x3 grid of abilities with live cooldown bars. */
public class AdminScreen extends Screen {
    private static final int COLS = 3;
    private static final int BTN_W = 118;
    private static final int BTN_H = 38;
    private static final int GAP = 6;
    private static final int PAD = 16;
    private static final int HEADER = 34;
    private static final int FOOTER = 36;

    private final List<Button> buttons = new ArrayList<>();

    private int panelX, panelY, panelW, panelH;

    public AdminScreen() {
        super(Component.literal("Game Administrator"));
    }

    @Override
    protected void init() {
        buttons.clear();

        int rows = (Ability.ALL.length + COLS - 1) / COLS;
        int gridW = COLS * BTN_W + (COLS - 1) * GAP;
        int gridH = rows * BTN_H + (rows - 1) * GAP;

        panelW = gridW + PAD * 2;
        panelH = HEADER + gridH + FOOTER + PAD;
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;

        int gridX = panelX + PAD;
        int gridY = panelY + HEADER;

        for (int i = 0; i < Ability.ALL.length; i++) {
            final int index = i;
            final Ability ability = Ability.ALL[i];
            int bx = gridX + (i % COLS) * (BTN_W + GAP);
            int by = gridY + (i / COLS) * (BTN_H + GAP);

            Button button = Button.builder(Component.literal(ability.label), b -> {
                        ClientState.lastCast = index;
                        ClientPlayNetworking.send(new CastRequestPayload(index));
                        this.onClose();
                    })
                    .bounds(bx, by, BTN_W, BTN_H)
                    .tooltip(Tooltip.create(Component.literal(ability.description)))
                    .build();
            this.addRenderableWidget(button);
            buttons.add(button);
        }

        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> this.onClose())
                .bounds(panelX + panelW / 2 - 40, panelY + panelH - FOOTER + 8, 80, 20)
                .build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        super.extractBackground(g, mouseX, mouseY, partialTick);

        // panel
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xE60B0B14);
        g.outline(panelX, panelY, panelW, panelH, 0xFF7C4DFF);
        g.outline(panelX + 1, panelY + 1, panelW - 2, panelH - 2, 0x557C4DFF);

        // header bar
        g.fill(panelX + 2, panelY + 2, panelX + panelW - 2, panelY + 24, 0xFF1A1030);
        g.fill(panelX + 2, panelY + 24, panelX + panelW - 2, panelY + 25, 0xFF7C4DFF);

        String title = "GAME ADMINISTRATOR";
        g.text(this.font, title, panelX + (panelW - this.font.width(title)) / 2, panelY + 9, 0xFFE9DDFF, true);

        String hint = "Click an ability to cast it   |   V repeats the last one";
        g.text(this.font, hint, panelX + (panelW - this.font.width(hint)) / 2, panelY + 27, 0xFF8F86AA, false);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        // live cooldown text on the buttons
        for (int i = 0; i < buttons.size(); i++) {
            Ability a = Ability.ALL[i];
            long rem = ClientState.remainingMs(i);
            Button b = buttons.get(i);
            if (rem > 0) {
                b.setMessage(Component.literal(a.label + "  " + ((rem + 999) / 1000) + "s"));
            } else {
                b.setMessage(Component.literal(a.label));
            }
        }

        super.extractRenderState(g, mouseX, mouseY, partialTick);

        // accent stripe + cooldown bar drawn over the buttons
        for (int i = 0; i < buttons.size(); i++) {
            Ability a = Ability.ALL[i];
            Button b = buttons.get(i);
            int x = b.getX(), y = b.getY(), w = b.getWidth(), h = b.getHeight();
            int accent = 0xFF000000 | a.rgb;

            g.fill(x, y, x + 3, y + h, accent);

            long rem = ClientState.remainingMs(i);
            if (rem > 0) {
                float frac = Math.min(1f, rem / (float) a.cooldownMs);
                g.fill(x, y + h - 3, x + w, y + h, 0xAA000000);
                g.fill(x, y + h - 3, x + (int) (w * frac), y + h, 0xFF000000 | a.rgb);
            }
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
