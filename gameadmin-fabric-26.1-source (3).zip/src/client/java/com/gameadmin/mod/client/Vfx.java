package com.gameadmin.mod.client;

import com.gameadmin.mod.Ability;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Screen VFX. Everything here is drawn with plain rectangles, gradients and outlines on the HUD layer:
 * flashes, vignettes, streaks, expanding rings, scanlines and glitch bars. No particles anywhere.
 */
public final class Vfx {
    private Vfx() {}

    private static final class Active {
        final int ability;
        final long start;
        final int value;

        Active(int ability, long start, int value) {
            this.ability = ability;
            this.start = start;
            this.value = value;
        }
    }

    private static final List<Active> ACTIVE = new ArrayList<>();
    private static String toastText = null;
    private static int toastRgb = 0xFFFFFF;
    private static long toastStart = 0;
    private static final long TOAST_MS = 2200;

    public static void start(int ability, int value) {
        ACTIVE.removeIf(a -> a.ability == ability);
        ACTIVE.add(new Active(ability, System.currentTimeMillis(), value));
        Ability ab = Ability.ALL[ability];
        toast(ab.label + describe(ability, value), ab.rgb);
    }

    public static void toast(String text, int rgb) {
        toastText = text;
        toastRgb = rgb;
        toastStart = System.currentTimeMillis();
    }

    private static String describe(int ability, int value) {
        return switch (Ability.ALL[ability]) {
            case SMITE -> value > 0 ? "  x" + value : "  (nothing to strike)";
            case PURGE -> "  " + value + " removed";
            case FREEZE -> "  " + value + " frozen";
            case WEATHER -> "  " + new String[]{"clear", "rain", "thunder"}[Math.floorMod(value, 3)];
            default -> "";
        };
    }

    // ------------------------------------------------------------------ main hook

    public static void extract(GuiGraphicsExtractor g, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            ACTIVE.clear();
            toastText = null;
            return;
        }
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        long now = System.currentTimeMillis();

        Iterator<Active> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Active a = it.next();
            Ability ab = Ability.ALL[a.ability];
            long elapsed = now - a.start;
            if (elapsed >= ab.vfxMs) {
                it.remove();
                continue;
            }
            float t = elapsed / (float) ab.vfxMs;
            switch (ab) {
                case SMITE -> smite(g, w, h, t, a.start);
                case BLINK -> blink(g, w, h, t);
                case TIME_WARP -> timeWarp(g, w, h, t);
                case WEATHER -> weather(g, w, h, t);
                case RESTORE -> restore(g, w, h, t);
                case GOD_MODE -> godMode(g, mc, w, h, t, ab.vfxMs - elapsed);
                case SKYWARD -> skyward(g, w, h, t);
                case FREEZE -> freeze(g, w, h, t);
                case PURGE -> purge(g, mc, w, h, t, elapsed, a.value);
            }
        }

        drawToast(g, mc, w, now);
    }

    private static void drawToast(GuiGraphicsExtractor g, Minecraft mc, int w, long now) {
        if (toastText == null) return;
        long el = now - toastStart;
        if (el > TOAST_MS) {
            toastText = null;
            return;
        }
        float a = 1f;
        if (el < 150) a = el / 150f;
        else if (el > TOAST_MS - 400) a = (TOAST_MS - el) / 400f;

        int tw = mc.font.width(toastText);
        int x = (w - tw) / 2;
        int y = 22;
        box(g, x - 8, y - 4, x + tw + 8, y + 13, 0x000000, 0.65f * a);
        box(g, x - 8, y + 12, x + tw + 8, y + 13, toastRgb, a);
        g.text(mc.font, toastText, x, y, col(toastRgb, a), true);
    }

    // ------------------------------------------------------------------ the nine effects

    /** Flash of white, a jagged bolt tearing down the screen, violet edge glow. */
    private static void smite(GuiGraphicsExtractor g, int w, int h, float t, long seed) {
        float inv = 1f - t;
        box(g, 0, 0, w, h, 0xFFFFFF, 0.85f * inv * inv * inv);
        vignette(g, w, h, 0x8A6BFF, 0.55f * inv, h / 5);

        if (t < 0.7f) {
            float bolt = 1f - t / 0.7f;
            int x = w / 2 + (int) ((rnd((int) seed) - 0.5f) * w * 0.4f);
            int segs = 14;
            int segH = h / segs + 1;
            for (int i = 0; i < segs; i++) {
                x += (int) ((rnd(i * 31 + (int) (seed & 0xFFFF)) - 0.5f) * 36f);
                int y = i * segH;
                box(g, x - 7, y, x + 8, y + segH, 0x9FB4FF, 0.30f * bolt);
                box(g, x - 2, y, x + 3, y + segH, 0xFFFFFF, 0.95f * bolt);
            }
        }
    }

    /** Cyan speed lines rush in from both edges while a tunnel vignette pulses. */
    private static void blink(GuiGraphicsExtractor g, int w, int h, float t) {
        float inv = 1f - t;
        float ease = 1f - (1f - t) * (1f - t);
        vignette(g, w, h, 0x55E6FF, 0.75f * inv, h / 3);
        for (int i = 0; i < 34; i++) {
            int y = (int) (rnd(i * 7 + 1) * h);
            int len = (int) ((0.12f + 0.38f * rnd(i * 13 + 5)) * w * ease);
            int th = 1 + (i % 3 == 0 ? 1 : 0);
            box(g, 0, y, len, y + th, 0xBFF6FF, 0.85f * inv);
            box(g, w - len, y, w, y + th, 0xBFF6FF, 0.85f * inv);
        }
        box(g, 0, 0, w, h, 0xFFFFFF, 0.25f * inv * inv);
    }

    /** Gold tint, expanding clock rings and two spinning clock hands. */
    private static void timeWarp(GuiGraphicsExtractor g, int w, int h, float t) {
        float fade = fadeInOut(t, 0.15f, 0.35f);
        g.fillGradient(0, 0, w, h, col(0xFFD36B, 0.30f * fade), col(0xFF8A00, 0.30f * fade));

        int cx = w / 2, cy = h / 2;
        int reach = Math.max(w, h) / 2;
        for (int i = 0; i < 5; i++) {
            float p = frac(t * 1.2f + i * 0.2f);
            int hw = (int) (p * reach);
            int hh = (int) (p * reach * 0.62f);
            float a = (1f - p) * fade;
            g.outline(cx - hw, cy - hh, hw * 2, hh * 2, col(0xFFE08A, a));
            g.outline(cx - hw - 1, cy - hh - 1, hw * 2 + 2, hh * 2 + 2, col(0xFFC94D, a * 0.6f));
        }
        hand(g, cx, cy, 60, t * 40f, 0xFFF3C4, fade);
        hand(g, cx, cy, 38, t * 3.3f, 0xFFC94D, fade);
        box(g, cx - 2, cy - 2, cx + 3, cy + 3, 0xFFFFFF, fade);
    }

    /** Cold grey-blue wash, a sweeping band and streaks falling across the screen. */
    private static void weather(GuiGraphicsExtractor g, int w, int h, float t) {
        float fade = fadeInOut(t, 0.2f, 0.4f);
        g.fillGradient(0, 0, w, h, col(0x4A5E78, 0.45f * fade), col(0x9DB6D4, 0.10f * fade));

        int bandY = (int) (frac(t * 1.4f) * h);
        g.fillGradient(0, Math.max(0, bandY - 50), w, bandY, col(0xBFD6F2, 0f), col(0xBFD6F2, 0.28f * fade));
        box(g, 0, bandY, w, bandY + 2, 0xE6F2FF, 0.6f * fade);

        for (int i = 0; i < 70; i++) {
            int x = (int) (rnd(i * 5 + 3) * w);
            float speed = 1.6f + 1.8f * rnd(i * 11 + 2);
            int y = (int) (frac(t * speed + rnd(i * 17 + 9)) * (h + 40)) - 20;
            int len = 10 + (int) (rnd(i * 3 + 8) * 14);
            box(g, x, y, x + 1, y + len, 0xCFE4FF, 0.55f * fade);
        }
    }

    /** Green healing wave rising from the bottom plus a swelling cross. */
    private static void restore(GuiGraphicsExtractor g, int w, int h, float t) {
        float inv = 1f - t;
        float rise = 1f - (1f - t) * (1f - t);
        int top = (int) (h * (1f - rise));
        g.fillGradient(0, top, w, h, col(0x4DFF88, 0f), col(0x4DFF88, 0.55f * inv));
        box(g, 0, top, w, top + 2, 0xC8FFD9, 0.9f * inv);
        vignette(g, w, h, 0x4DFF88, 0.55f * inv, h / 4);

        int cx = w / 2, cy = h / 2;
        int arm = (int) (14 + 60 * rise);
        int th = (int) (4 + 6 * rise);
        float a = 0.9f * inv;
        box(g, cx - arm, cy - th, cx + arm, cy + th, 0xDFFFEA, a);
        box(g, cx - th, cy - arm, cx + th, cy + arm, 0xDFFFEA, a);
    }

    /** Pulsing golden frame for the whole 20 seconds, with a live countdown. */
    private static void godMode(GuiGraphicsExtractor g, Minecraft mc, int w, int h, float t, long remainingMs) {
        float intro = Math.max(0f, 1f - t * 40f); // first ~0.5 s flash
        float fadeOut = remainingMs < 1500 ? remainingMs / 1500f : 1f;
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 220.0);

        box(g, 0, 0, w, h, 0xFFE680, 0.55f * intro);
        vignette(g, w, h, 0xFFD700, (0.28f + 0.22f * pulse) * fadeOut, h / 4);
        g.outline(4, 4, w - 8, h - 8, col(0xFFE680, (0.35f + 0.35f * pulse) * fadeOut));

        String text = "GOD MODE  " + ((remainingMs + 999) / 1000) + "s";
        int tw = mc.font.width(text);
        box(g, w / 2 - tw / 2 - 6, h - 58, w / 2 + tw / 2 + 6, h - 44, 0x000000, 0.55f * fadeOut);
        g.text(mc.font, text, w / 2 - tw / 2, h - 54, col(0xFFE680, fadeOut), true);
    }

    /** White streaks racing upward and a growing white-out at the top of the screen. */
    private static void skyward(GuiGraphicsExtractor g, int w, int h, float t) {
        float fade = fadeInOut(t, 0.1f, 0.5f);
        for (int i = 0; i < 46; i++) {
            int x = (int) (rnd(i * 9 + 4) * w);
            float speed = 2.2f + 2.2f * rnd(i * 5 + 1);
            int len = 22 + (int) (rnd(i * 7 + 6) * 60);
            int y = h - (int) (frac(t * speed + rnd(i * 3 + 2)) * (h + len)) ;
            box(g, x, y, x + 2, y + len, 0xFFFFFF, 0.7f * fade);
        }
        g.fillGradient(0, 0, w, h / 2, col(0xFFFFFF, 0.65f * t), col(0xFFFFFF, 0f));
        vignette(g, w, h, 0xBFD8FF, 0.45f * fade, h / 6);
    }

    /** Frosted corners and icy edges that slowly thaw. */
    private static void freeze(GuiGraphicsExtractor g, int w, int h, float t) {
        float fade = t < 0.1f ? t / 0.1f : 1f - (t - 0.1f) / 0.9f;
        fade = Math.max(0f, fade);
        box(g, 0, 0, w, h, 0x9FE8FF, 0.16f * fade);
        vignette(g, w, h, 0x8FEFFF, 0.85f * fade, h / 3);

        int size = Math.min(w, h) / 3;
        for (int k = 0; k < size; k += 2) {
            int len = (size - k) * 2;
            float a = 0.55f * fade * (1f - k / (float) size);
            box(g, 0, k, len, k + 2, 0xE8FBFF, a);                 // top-left
            box(g, w - len, k, w, k + 2, 0xE8FBFF, a);             // top-right
            box(g, 0, h - k - 2, len, h - k, 0xE8FBFF, a);         // bottom-left
            box(g, w - len, h - k - 2, w, h - k, 0xE8FBFF, a);     // bottom-right
        }
        // a few crack lines
        for (int i = 0; i < 6; i++) {
            int x = (int) (rnd(i * 4 + 1) * w);
            int y0 = (int) (rnd(i * 6 + 2) * h * 0.3f);
            int len = (int) (h * 0.15f + rnd(i * 8 + 3) * h * 0.2f * Math.min(1f, t * 4f));
            box(g, x, y0, x + 1, y0 + len, 0xFFFFFF, 0.5f * fade);
        }
    }

    /** Red flicker, a descending scanline and glitch bars. */
    private static void purge(GuiGraphicsExtractor g, Minecraft mc, int w, int h, float t, long elapsed, int count) {
        float inv = 1f - t;
        int frame = (int) (elapsed / 55);
        float flicker = 0.12f + 0.12f * rnd(frame * 3 + 1);
        box(g, 0, 0, w, h, 0xFF1A1A, flicker * inv * 2f);
        vignette(g, w, h, 0xFF2A2A, 0.6f * inv, h / 4);

        int y = (int) (Math.min(1.1f, t * 1.25f) * h);
        g.fillGradient(0, Math.max(0, y - 70), w, y, col(0xFF3030, 0f), col(0xFF3030, 0.35f * inv));
        box(g, 0, y, w, y + 3, 0xFFB0B0, 0.85f * inv);

        for (int i = 0; i < 10; i++) {
            float r = rnd(frame * 31 + i);
            int by = (int) (rnd(frame * 17 + i * 3) * h);
            int bh = 2 + (int) (rnd(frame * 5 + i) * 10);
            int bx = (int) (rnd(frame * 11 + i) * w * 0.55f);
            int bw = (int) (w * (0.15f + 0.55f * rnd(frame * 19 + i)));
            int rgb = r < 0.5f ? 0xFF2020 : (r < 0.8f ? 0xFFFFFF : 0x000000);
            box(g, bx, by, bx + bw, by + bh, rgb, 0.5f * inv);
        }

        String text = "HOSTILES PURGED: " + count;
        int jx = (int) ((rnd(frame * 7 + 2) - 0.5f) * 8f);
        int jy = (int) ((rnd(frame * 9 + 4) - 0.5f) * 4f);
        int tw = mc.font.width(text);
        g.text(mc.font, text, w / 2 - tw / 2 + jx + 1, h / 2 + jy + 1, col(0x00FFFF, 0.6f * inv), false);
        g.text(mc.font, text, w / 2 - tw / 2 + jx, h / 2 + jy, col(0xFF4040, inv), true);
    }

    // ------------------------------------------------------------------ drawing helpers

    /** ARGB from an RGB colour and a 0..1 alpha. */
    private static int col(int rgb, float alpha) {
        int a = Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f);
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    /** Filled rectangle that quietly skips invisible or empty boxes. */
    private static void box(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int rgb, float alpha) {
        if (alpha < 0.004f || x2 <= x1 || y2 <= y1) return;
        g.fill(x1, y1, x2, y2, col(rgb, alpha));
    }

    /** Soft coloured frame around the screen edges, strongest at the very edge. */
    private static void vignette(GuiGraphicsExtractor g, int w, int h, int rgb, float alpha, int thick) {
        int layers = 10;
        for (int k = 0; k < layers; k++) {
            float f = 1f - k / (float) layers;
            float a = alpha * f * f;
            int t0 = thick * k / layers;
            int t1 = thick * (k + 1) / layers;
            if (t1 <= t0) continue;
            box(g, 0, t0, w, t1, rgb, a);              // top
            box(g, 0, h - t1, w, h - t0, rgb, a);      // bottom
            box(g, t0, t1, t1, h - t1, rgb, a);        // left
            box(g, w - t1, t1, w - t0, h - t1, rgb, a);// right
        }
    }

    /** A clock hand drawn as a short dotted line. */
    private static void hand(GuiGraphicsExtractor g, int cx, int cy, int len, float angle, int rgb, float alpha) {
        double cos = Math.cos(angle), sin = Math.sin(angle);
        for (int r = 4; r <= len; r += 2) {
            int x = cx + (int) (cos * r);
            int y = cy + (int) (sin * r);
            box(g, x - 1, y - 1, x + 1, y + 1, rgb, alpha);
        }
    }

    private static float fadeInOut(float t, float in, float out) {
        if (t < in) return t / in;
        if (t > 1f - out) return Math.max(0f, (1f - t) / out);
        return 1f;
    }

    private static float frac(float v) {
        return v - (float) Math.floor(v);
    }

    /** Cheap deterministic pseudo random number in [0,1) from an integer. */
    private static float rnd(int n) {
        int h = n * 0x9E3779B1;
        h ^= h >>> 15;
        h *= 0x85EBCA6B;
        h ^= h >>> 13;
        return (h & 0xFFFFFF) / (float) 0x1000000;
    }
}
